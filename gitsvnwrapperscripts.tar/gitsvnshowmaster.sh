#!/bin/bash
# script  to set the active master svn tracking branch
# will only run if that master is checked out

cat ~/.gitsvnactivetrackingbranch
